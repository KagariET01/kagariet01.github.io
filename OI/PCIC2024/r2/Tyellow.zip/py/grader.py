def B_add_A(x: int, y: int):
    if (x < 1 or y < 1 or x > 1000000 or y > N):
        wa("index out of range")
    black_box.B[x] += black_box.A[y]
    if black_box.B[x] > 100000000000000000:
        black_box.B[x] = 100000000000000000
    if black_box.B[x] < -100000000000000000:
        black_box.B[x] = -100000000000000000

def B_sub_A(x: int, y: int):
    if (x < 1 or y < 1 or x > 1000000 or y > N):
        wa("index out of range")
    black_box.B[x] -= black_box.A[y]
    if black_box.B[x] > 100000000000000000:
        black_box.B[x] = 100000000000000000
    if black_box.B[x] < -100000000000000000:
        black_box.B[x] = -100000000000000000

def B_add_B(x: int, y: int):
    if (x < 1 or y < 1 or x > 1000000 or y > 1000000):
        wa("index out of range")
    black_box.B[x] += black_box.B[y]
    if black_box.B[x] > 100000000000000000:
        black_box.B[x] = 100000000000000000
    if black_box.B[x] < -100000000000000000:
        black_box.B[x] = -100000000000000000

def B_sub_B(x: int, y: int):
    if (x < 1 or y < 1 or x > 1000000 or y > 1000000):
        wa("index out of range")
    black_box.B[x] -= black_box.B[y]
    if black_box.B[x] > 100000000000000000:
        black_box.B[x] = 100000000000000000
    if black_box.B[x] < -100000000000000000:
        black_box.B[x] = -100000000000000000

def abs_B(x: int):
    if(x < 1 or x > 1000000):
        wa("index out of range")
    if(black_box.B[x] < 0):
        black_box.B[x] *= -1
    if black_box.B[x] > 100000000000000000:
        black_box.B[x] = 100000000000000000

def ask_Tyellow(x: int) -> bool:
    if(x < 1 or x > 1000000):
        wa("index out of range")
    black_box.count1 += 1
    return (black_box.B[x] != 0)

def set_B(x:int ,c:int):
    if(x < 1 or x > 1000000):
        wa("index out of range")
    if(c < -1000000000 or c > 1000000000):
        wa("index out of range")
    black_box.count2 += 1
    black_box.B[x] = c

if __name__ == '__main__':
    N, K = map(int, input().split(' '))

    import Tyellow

    def wa(msg):
        print('Wrong Answer: ' + msg)
        exit(0)

    class Black_Box:
        def __init__(self, N, K):
            self.count1 = 0
            self.count2 = 0
            self.A = [0]*1010
            self.B = [0]*1000010
            self.N = N
            self.K = K

    black_box = Black_Box(N, K)
    for i,j in enumerate(input().split(' ')):
        black_box.A[i+1] = int(j)
    password = Tyellow.game_start(N,K)
    ans = 0
    for i in range(1,N+1):
        if(black_box.A[i] >= K):
            ans += black_box.A[i] * i
    if password == ans:
        print(f"Accepted: {N} {K} {black_box.count1} {black_box.count2}")
    else:
        print(f"Wrong Answer: incorrect answer = {password}, answer = {ans}\n")
