def game_start(N: int,K: int) -> int:
    from __main__ import B_add_A,B_sub_A,B_add_B,B_sub_B,abs_B,ask_Tyellow,set_B
    B_add_A(1,1)
    B_sub_A(1,1)
    B_add_B(1,1)
    B_sub_B(1,1)
    abs_B(1)
    set_B(1,0)
    ask_Tyellow(1)
    return 1
