#include "Tyellow.h"

#include <cassert>
#include <stdio.h>
#include <stdlib.h>

namespace {
    long long N, K;
    long long A[1010];
    long long B[1000010] = {0};
    int count1,count2;
    void wa(const char* msg) {
        printf("Wrong Answer: %s\n", msg);
        exit(0);
    }
}

void B_add_A(int x,int y){
    if (x < 1 || y < 1 || x > 1000000 || y > N)
        wa("index out of range");
    B[x] += A[y];
    if(B[x] > 100000000000000000) B[x] = 100000000000000000;
    if(B[x] < -100000000000000000) B[x] = -100000000000000000;
}

void B_sub_A(int x,int y){
    if (x < 1 || y < 1 || x > 1000000 || y > N)
        wa("index out of range");
    B[x] -= A[y];
    if(B[x] > 100000000000000000) B[x] = 100000000000000000;
    if(B[x] < -100000000000000000) B[x] = -100000000000000000;
}

void B_add_B(int x,int y){
    if (x < 1 || y < 1 || x > 1000000 || y > 1000000)
        wa("index out of range");
    B[x] += B[y];
    if(B[x] > 100000000000000000) B[x] = 100000000000000000;
    if(B[x] < -100000000000000000) B[x] = -100000000000000000;
}

void B_sub_B(int x,int y){
    if (x < 1 || y < 1 || x > 1000000 || y > 1000000)
        wa("index out of range");
    B[x] -= B[y];
    if(B[x] > 100000000000000000) B[x] = 100000000000000000;
    if(B[x] < -100000000000000000) B[x] = -100000000000000000;
}

void abs_B(int x){
    if (x < 1 || x > 1000000)
        wa("index out of range");
    if(B[x] < 0){
        B[x] *= -1;
    }
    if(B[x] > 100000000000000000) B[x] = 100000000000000000;
}

bool ask_Tyellow(int x){
    count1++;
    if (x < 1 || x > 1000000)
        wa("index out of range");
    return (B[x] != 0);
}

void set_B(int x,int c){
    count2++;
    if (x < 1 || x > 1000000)
        wa("index out of range");
    if (c < -1000000000 || c > 1000000000)
        wa("constant out of range");
    B[x] = c;
}

int main() {
    assert(2 == scanf("%lld %lld", &N, &K));
    for(int i=1;i<=N;i++){
        assert(1 == scanf("%lld", &A[i]));
    }
    long long password = game_start(N,K);
    long long ans = 0;
    for(int i=1;i<=N;i++){
        if(A[i] >= K){
            ans += A[i] * i;
        }
    }
    if (password == ans)
        printf("Accepted: %lld %lld %d %d\n", N, K, count1, count2);
    else
        printf("Wrong Answer: incorrect answer = %lld, answer = %lld\n", password, ans);
}
