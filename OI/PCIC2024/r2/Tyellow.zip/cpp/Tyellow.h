#ifndef TYELLOW_H_
#define TYELLOW_H_

long long game_start(int N,int K);

void B_add_A(int x,int y);

void B_sub_A(int x,int y);

void B_add_B(int x,int y);

void B_sub_B(int x,int y);

void abs_B(int x);

bool ask_Tyellow(int x);

void set_B(int x,int c);

#endif // TYELLOW_H_
